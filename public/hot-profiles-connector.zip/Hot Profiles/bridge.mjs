import http from "node:http";
import { createInstagramLoginManager } from "./instagram-login.mjs";
import { performanceInfo, proxyKey } from "./policy.mjs";
import { frameCache } from "./frame-cache.mjs";
import { randomBytes, randomInt, timingSafeEqual } from "node:crypto";
import os from "node:os";
import path from "node:path";
import { createStore, fail, uuid } from "./storage.mjs";
import { findBrowser, startBrowser } from "./browser.mjs";
import { discoverAndroid, openAndroidManager, startAndroid } from "./android.mjs";
import { discoverRuntime, startLocalAndroid } from "./android-runtime.mjs";
import { localSerial } from "./android-discovery.mjs";
import { createGateway, checkProxy } from "./proxy.mjs";

if (Number(process.versions.node.split(".")[0]) < 22)
  throw new Error("Hot Profiles precisa de Node.js 22 ou superior.");
const argument = (name) => {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : undefined;
};
const desktopOrigin = argument("--desktop-origin");
const desktop = !!desktopOrigin;
if (desktop) {
  const origin = new URL(desktopOrigin);
  if (
    !process.parentPort ||
    origin.protocol !== "http:" ||
    origin.hostname !== "127.0.0.1" ||
    !origin.port ||
    origin.origin !== desktopOrigin
  )
    throw new Error("O modo desktop requer o aplicativo local e uma origem loopback.");
}
let port = Number(argument("--port") || 47900);
if (!Number.isInteger(port) || (port < 1024 && !(desktop && port === 0)) || port > 65535)
  throw new Error("Porta inválida.");
const directory = path.resolve(
  argument("--data-dir") ||
    path.join(process.env.LOCALAPPDATA || os.homedir(), "00duHot", "HotProfiles"),
);
const origins = new Set([
  "https://mausehot.vercel.app",
  "http://127.0.0.1:8081",
  "http://localhost:8081",
  "http://127.0.0.1:8080",
  "http://localhost:8080",
]);
if (desktop) {
  origins.clear();
  origins.add(desktopOrigin);
}
const additionalOrigin = argument("--allow-origin");
if (additionalOrigin) {
  const origin = new URL(additionalOrigin);
  if (origin.origin !== additionalOrigin || !["https:", "http:"].includes(origin.protocol))
    throw new Error("Informe uma origem exata, sem caminho.");
  origins.add(origin.origin);
}
const requestedLimit = argument("--max-sessions");
if (
  requestedLimit !== undefined &&
  (!/^\d+$/.test(requestedLimit) || Number(requestedLimit) < 1 || Number(requestedLimit) > 8)
)
  throw new Error("Use --max-sessions entre 1 e 8.");
const limits = performanceInfo(requestedLimit ? Number(requestedLimit) : undefined);
const store = await createStore(directory);
const token = randomBytes(32).toString("base64url");
let pairCode = String(randomInt(100000, 1000000));
let pairExpires = Date.now() + 15 * 60 * 1000;
let attempts = [];
const sessions = new Map();
const instagramLogin = createInstagramLoginManager({ directory });
let shuttingDown = false;
const equal = (a, b) => {
  if (typeof a !== "string") return false;
  const first = Buffer.from(a),
    second = Buffer.from(b);
  return first.length === second.length && timingSafeEqual(first, second);
};
const sessionInfo = (session) => ({
  profileId: session.profile.id,
  kind: session.profile.kind,
  name: session.profile.name,
  status: session.status,
  startedAt: session.startedAt,
  error: session.error || null,
  needsCleanup: session.status === "error" && !!session.runtime,
  androidBinding: session.androidBinding || null,
  runtimeInfo: session.runtime?.info || null,
});
const active = (id) => {
  const session = sessions.get(id);
  return (
    !!session &&
    (["starting", "running", "stopping"].includes(session.status) ||
      (session.status === "error" && !!session.runtime))
  );
};
const publicState = () => ({
  profiles: store.data.profiles,
  proxies: store.data.proxies.map(store.publicProxy),
  sessions: [...sessions.values()].map(sessionInfo),
  activities: store.data.activities,
  performance: performanceInfo(limits.maxSessions),
});
async function body(request) {
  let size = 0;
  const chunks = [];
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 32768) fail("Envio excede 32 KB.", 413);
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString() || "{}");
  } catch {
    fail("O conteúdo enviado não é válido.");
  }
}
function send(response, status, value) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
  });
  response.end(JSON.stringify(value));
}
async function stopSession(session) {
  if (!session || session.status === "stopped") return;
  if (session.status === "starting") {
    session.cancelled = true;
    session.abort.abort();
    return;
  }
  session.frames.clear();
  session.status = "stopping";
  try {
    await session.runtime?.stop();
    session.runtime = null;
    session.gateway?.close();
    session.status = "stopped";
    session.error = null;
    await store.activity("Sessão encerrada", session.profile);
  } catch (error) {
    session.status = "error";
    session.error = error.message;
    // Preserve a gateway if Android proxy restoration failed; a second stop can retry.
    throw error;
  }
}
async function launch(profile) {
  if (
    [...sessions.values()].filter((session) => active(session.profile.id)).length >=
    limits.maxSessions
  )
    fail(
      `Encerre um ambiente antes de abrir outro. Este conector está limitado a ${limits.maxSessions} sessões simultâneas.`,
      409,
    );
  if (active(profile.id)) fail("Este perfil já tem uma sessão aberta.", 409);
  if (
    profile.deviceId?.startsWith("runtime:") &&
    [...sessions.values()].some(
      (other) => active(other.profile.id) && other.profile.deviceId?.startsWith("runtime:"),
    )
  )
    fail(
      "O protótipo permite um celular próprio por vez. Encerre o atual antes de iniciar outro.",
      409,
    );
  if (
    profile.kind === "android" &&
    [...sessions.values()].some(
      (session) => active(session.profile.id) && session.profile.deviceId === profile.deviceId,
    )
  )
    fail("Esta instância Android já está em uso.", 409);
  const selectedProxy = profile.proxyId ? store.proxy(profile.proxyId) : null;
  if (profile.proxyId && !selectedProxy) fail("O proxy deste perfil não está disponível.");
  if (
    selectedProxy &&
    [...sessions.values()].some((session) => {
      const other = session.profile.proxyId ? store.proxy(session.profile.proxyId) : null;
      return active(session.profile.id) && other && proxyKey(other) === proxyKey(selectedProxy);
    })
  )
    fail("Este proxy já está em uso por outro perfil. Escolha uma conexão diferente.", 409);
  const session = {
    frames: frameCache(),
    profile,
    status: "starting",
    startedAt: new Date().toISOString(),
    runtime: null,
    gateway: null,
    cancelled: false,
    control: Promise.resolve(),
    controlCount: 0,
    capturing: false,
    abort: new AbortController(),
    ready: null,
  };
  sessions.set(profile.id, session);
  session.ready = (async () => {
    try {
      const proxy = profile.proxyId ? store.proxy(profile.proxyId) : null;
      if (profile.proxyId && !proxy) fail("O proxy deste perfil não está mais disponível.");
      if (proxy) {
        await checkProxy(proxy);
        session.gateway = await createGateway(proxy);
      }
      session.runtime =
        profile.kind === "browser"
          ? await startBrowser(
              profile,
              directory,
              session.gateway,
              () => {
                if (session.status === "running") {
                  session.status = "stopped";
                  session.gateway?.close();
                }
              },
              session.abort.signal,
            )
          : await (
              profile.deviceId.startsWith("runtime:")
                ? (p, g, s, bind) =>
                    startLocalAndroid(p, directory, g, s, bind, {
                      onUnexpectedExit: () => {
                        if (session.status === "running") {
                          session.status = "error";
                          session.error =
                            "O motor Android encerrou. Encerre a sessão antes de iniciar novamente.";
                          session.frames.clear();
                        }
                      },
                    })
                : startAndroid
            )(profile, session.gateway, session.abort.signal, async (binding) => {
              if (
                [...sessions.values()].some(
                  (other) =>
                    other !== session &&
                    active(other.profile.id) &&
                    other.androidBinding?.endpoint === binding.endpoint,
                )
              )
                fail("Este endpoint Android já está em uso por outra sessão.", 409);
              // Reserve before persisting or touching Android proxy settings.
              session.androidBinding = binding;
              await store.bindAndroid(profile.id, binding);
            });
      // Android must expose a real screen before its session is ready. Chrome's
      // page compositor may still be loading; its authenticated CDP connection
      // already confirms the process and the viewer retries frames independently.
      if (profile.kind === "android") await session.runtime.frame();
      session.status = "running";
      await store.activity("Sessão iniciada", profile);
      if (session.cancelled || shuttingDown) await stopSession(session);
    } catch (error) {
      if (error.cleanupRuntime) session.runtime = error.cleanupRuntime;
      try {
        await session.runtime?.stop();
        session.runtime = null;
      } catch {}
      if (!session.runtime) session.gateway?.close();
      session.status = session.cancelled && !session.runtime ? "stopped" : "error";
      session.error =
        session.status === "stopped" ? null : error.message || "Não foi possível iniciar a sessão.";
    }
  })();
  return sessionInfo(session);
}

const server = http.createServer(async (request, response) => {
  try {
    if (![`127.0.0.1:${port}`, `localhost:${port}`].includes(request.headers.host))
      fail("Endereço do conector não autorizado.", 403);
    const origin = request.headers.origin;
    if (origin && !origins.has(origin))
      fail("Este site não está autorizado a acessar o conector.", 403);
    if (origin) response.setHeader("Access-Control-Allow-Origin", origin);
    response.setHeader("Vary", "Origin");
    response.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
    response.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS");
    response.setHeader("Access-Control-Allow-Private-Network", "true");
    if (request.method === "OPTIONS") {
      response.writeHead(204);
      response.end();
      return;
    }
    const url = new URL(request.url, `http://127.0.0.1:${port}`);
    if (url.pathname === "/health" && request.method === "GET") {
      send(response, 200, { name: "Hot Profiles", version: 2 });
      return;
    }
    if (url.pathname === "/pair" && request.method === "POST") {
      if (desktop) fail("O aplicativo desktop usa conexão privada local.", 404);
      if (!origin || !origins.has(origin))
        fail("Abra o Hot Profiles para conectar este computador.", 403);
      attempts = attempts.filter((attempt) => attempt > Date.now() - 60000);
      if (attempts.length >= 5) fail("Muitas tentativas. Aguarde um minuto.", 429);
      attempts.push(Date.now());
      const input = await body(request);
      if (Date.now() > pairExpires || !equal(input.code, pairCode))
        fail(
          "Código inválido ou expirado. Use o código atual mostrado na janela do conector.",
          401,
        );
      attempts = [];
      send(response, 200, { token, computer: os.hostname() });
      return;
    }
    const authorization = request.headers.authorization;
    if (!equal(authorization, `Bearer ${token}`)) fail("Conecte este computador novamente.", 401);
    if (shuttingDown) fail("O conector está encerrando.", 503);
    const segments = url.pathname.split("/").filter(Boolean);
    const [version, collection, id, action] = segments;
    if (version !== "v1") fail("Operação não encontrada.", 404);
    const method = request.method;
    if (collection === "instagram-login" && method === "POST") {
      if (!origin || !origins.has(origin)) fail("Origem não autorizada.", 403);
      send(response, 201, await instagramLogin.open(await body(request), origin));
      return;
    }
    if (collection === "state" && method === "GET") {
      send(response, 200, publicState());
      return;
    }
    if (collection === "devices" && method === "GET") {
      const runtime = await discoverRuntime();
      send(response, 200, {
        ...(await discoverAndroid()),
        runtime: {
          available: runtime.available,
          message: runtime.message,
          api: runtime.image?.api,
          images: runtime.images.map(({ id, api, description, minRamMb }) => ({
            id,
            api,
            description,
            minRamMb,
          })),
        },
        browserAvailable: !!(await findBrowser()),
        performance: performanceInfo(limits.maxSessions),
        computer: os.hostname(),
      });
      return;
    }
    if (collection === "android" && id === "manager" && method === "POST") {
      send(response, 200, await openAndroidManager());
      return;
    }
    if (!["profiles", "proxies", "sessions"].includes(collection) || (id && !uuid(id)))
      fail("Operação não encontrada.", 404);
    if (collection === "profiles") {
      const profile = id ? store.data.profiles.find((item) => item.id === id) : null;
      if (id && !profile) fail("Perfil não encontrado.", 404);
      if (method === "POST" && action === "start") {
        send(response, 202, await launch(profile));
        return;
      }
      if (method === "POST" && action === "stop") {
        await stopSession(sessions.get(id));
        send(response, 200, publicState());
        return;
      }
      if (id && active(id)) fail("Encerre a sessão antes de editar ou excluir este perfil.", 409);
      if ((method === "POST" && !id) || (method === "PATCH" && id && !action)) {
        const input = await body(request);
        if (input.kind === "android" && !input.deviceId?.startsWith("runtime:")) {
          const device = (await discoverAndroid()).devices.find(
            (device) =>
              device.id === input.deviceId ||
              (input.deviceId?.startsWith("adb:") &&
                device.endpoint &&
                device.endpoint === localSerial(input.deviceId.slice(4))),
          );
          if (!device) fail("Selecione uma instância Android detectada neste computador.");
          input.deviceId = device.id;
        }
        send(response, 200, await store.putProfile(input, id));
        return;
      }
      if (method === "DELETE" && id && !action) {
        await store.remove("profiles", id);
        sessions.delete(id);
        send(response, 200, { ok: true });
        return;
      }
    }
    if (collection === "proxies") {
      if (method === "POST" && action === "check" && id) {
        const proxy = store.proxy(id);
        if (!proxy) fail("Proxy não encontrado.", 404);
        try {
          send(response, 200, await checkProxy(proxy));
        } catch (error) {
          send(response, 200, {
            ok: false,
            message: error.message,
            checkedAt: new Date().toISOString(),
          });
        }
        return;
      }
      if (
        id &&
        [...sessions.values()].some(
          (session) => active(session.profile.id) && session.profile.proxyId === id,
        )
      )
        fail("Este proxy está em uso. Encerre as sessões antes de alterá-lo.", 409);
      if ((method === "POST" && !id) || (method === "PATCH" && id && !action)) {
        send(response, 200, await store.putProxy(await body(request), id));
        return;
      }
      if (method === "DELETE" && id && !action) {
        if (store.data.profiles.some((profile) => profile.proxyId === id))
          fail("Remova este proxy dos perfis antes de excluí-lo.", 409);
        await store.remove("proxies", id);
        send(response, 200, { ok: true });
        return;
      }
    }
    if (collection === "sessions" && id) {
      const session = sessions.get(id);
      if (!session || session.status !== "running") fail("Esta sessão não está em execução.", 409);
      if (method === "GET" && action === "video" && session.runtime.stream) {
        session.runtime.stream(response);
        return;
      }
      if (method === "POST" && action === "network" && session.profile.kind === "android") {
        send(response, 200, await session.runtime.network());
        return;
      }
      if (method === "GET" && action === "frame") {
        send(response, 200, await session.frames.get(() => session.runtime.frame()));
        return;
      }
      if (
        action === "tabs" &&
        session.profile.kind === "browser" &&
        ["GET", "POST"].includes(method)
      ) {
        const tabs =
          method === "POST"
            ? await session.runtime.addTab((await body(request)).url)
            : await session.runtime.tabs();
        if (method === "POST") session.frames.clear();
        send(response, 200, tabs);
        return;
      }
      if (method === "POST" && action === "control") {
        if (session.controlCount >= 12) fail("Aguarde as ações anteriores terminarem.", 429);
        const input = await body(request);
        session.controlCount++;
        const operation = session.control
          .catch(() => {})
          .then(() => session.runtime.control(input));
        session.control = operation;
        try {
          await operation;
          session.frames.clear();
          send(response, 200, { ok: true });
        } finally {
          session.controlCount--;
        }
        return;
      }
    }
    fail("Operação não encontrada.", 404);
  } catch (error) {
    if (!response.headersSent && !response.destroyed)
      send(response, error.status || 500, {
        error:
          error.status || error.message?.startsWith("O ") || error.message?.startsWith("Não ")
            ? error.message
            : "Não foi possível concluir a operação no computador. Confira o conector.",
      });
    else response.end();
  }
});
server.requestTimeout = 30000;
server.headersTimeout = 10000;
server.on("error", (error) => {
  console.error(
    error.code === "EADDRINUSE"
      ? "Já existe um conector nesta porta. Feche-o ou use --port."
      : "Não foi possível abrir o conector local.",
  );
  process.exitCode = 1;
});
server.listen(port, "127.0.0.1", () => {
  port = server.address().port;
  if (desktop)
    process.parentPort.postMessage({
      type: "hot-profiles:ready",
      port,
      token,
      computer: os.hostname(),
    });
  else
    console.log(
      `\nHOT PROFILES — conector local\n\nEndereço: http://127.0.0.1:${port}\nDados: ${directory}\nLimite: ${limits.maxSessions} sessões · RAM: ${limits.totalGB} GB · processadores lógicos: ${limits.cores}\n\nCódigo de conexão: ${pairCode}\nVálido por 15 minutos. Digite-o apenas no seu painel 00duHot.\n\nMantenha esta janela aberta enquanto usa suas sessões. Ctrl+C para encerrar.\n`,
    );
});
const renewCode = setInterval(
  () => {
    pairCode = String(randomInt(100000, 1000000));
    pairExpires = Date.now() + 15 * 60 * 1000;
    if (!desktop) console.log(`Novo código de conexão: ${pairCode} (válido por 15 minutos).`);
  },
  15 * 60 * 1000,
);
renewCode.unref();
const shutdown = async () => {
  if (shuttingDown) return;
  shuttingDown = true;
  await instagramLogin.close();
  if (desktop) {
    try {
      await Promise.allSettled([...sessions.values()].map(stopSession));
      await Promise.allSettled([...sessions.values()].map((session) => session.ready));
      if ([...sessions.values()].some((session) => active(session.profile.id)))
        throw new Error("cleanup");
      await store.save();
      clearInterval(renewCode);
      server.closeAllConnections();
      server.close(() => process.exit(0));
    } catch {
      shuttingDown = false;
      process.parentPort.postMessage({ type: "hot-profiles:shutdown-blocked" });
    }
    return;
  }
  clearInterval(renewCode);
  server.close();
  const timeout = setTimeout(() => process.exit(1), 15000);
  timeout.unref();
  await Promise.allSettled([...sessions.values()].map(stopSession));
  await Promise.allSettled([...sessions.values()].map((session) => session.ready));
  await store.save();
  clearTimeout(timeout);
  process.exit(0);
};
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
if (desktop)
  process.parentPort.on("message", (event) => {
    if (event.data?.type === "hot-profiles:shutdown") void shutdown();
  });
